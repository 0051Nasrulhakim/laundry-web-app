<?= $this->extend('admin/index') ?>
<?= $this->section('content') ?>


        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">

                    <div class="d-flex flex-column h-100">
                        <h3 class="font-weight-bolder mb-0">Halaman Dashboard</h3>
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vero nesciunt quaerat quisquam nobis reprehenderit consequatur culpa expedita praesentium. Maiores est repellendus at ratione numquam earum perferendis error nulla temporibus corporis?
                        </p>

                    </div>
                </div>
            </div>
        </div>
    

<?= $this->endSection(); ?>